def find_peak_element(nums):
    left, right = 0, len(nums) - 1
    
    while left < right:
        mid = (left + right) // 2
        
        # Check if mid is a peak element
        if nums[mid] > nums[mid + 1]:
            # Peak is likely on the left side, move to the left
            right = mid
        else:
            # Peak is likely on the right side, move to the right
            left = mid + 1
    
    # 'left' or 'right' can be returned, as they are equal at this point
    return left

# Example usage:
nums = [1, 2, 2, 3, 4, 5, 8, 11, 8, 5, 3, 3, 2, 1]
peak_index = find_peak_element(nums)
print(peak_index)  # Output: 7