def min_height_after_operations(buildings, k):
    left, right = 1, max(buildings)

    while left <= right:
        mid = (left + right) // 2
        cost = 0

        for height in buildings:
            if height > mid:
                cost += height - mid

        if cost <= k:
            right = mid - 1
        else:
            left = mid + 1

    return left

def main():
    t = int(input("Enter the number of test cases: "))
    
    for _ in range(t):
        n, k = map(int, input().split())
        building_heights = list(map(int, input().split()))
        result = min_height_after_operations(building_heights, k)
        print(result)
