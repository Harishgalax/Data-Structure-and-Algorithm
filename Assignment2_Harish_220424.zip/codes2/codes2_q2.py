ef binary_search(arr, target, start, end, exclude_index):
    while start <= end:
        mid = (start + end) // 2
        if arr[mid] == target and mid != exclude_index:
            return mid
        elif arr[mid] < target:
            start = mid + 1
        else:
            end = mid - 1
    return -1

def find_pairs_with_sum(arr, target):
    result = []
    n = len(arr)

    for i in range(n):
        complement = target - arr[i]
        index = binary_search(arr, complement, 0, n - 1, i)
        
        if index != -1:
            result.append([i, index])

    return result

# Example usage
arr = [1, 2, 2, 3, 5, 7, 8, 9, 11]
target = 12
output = find_pairs_with_sum(arr, target)
print(output)